<?php
namespace App\Service;

interface AwsomeServiceInterface{
    public function doAwsomeThing();
}