<?php
namespace App\Service;

class AwsomeService implements AwsomeServiceInterface{

    public function doAwsomeThing(){
        echo "Hello There!";
    }

}