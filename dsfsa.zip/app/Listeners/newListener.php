<?php

// namespace App\Listeners;


// use App\Events\UserCreated;
// use App\Events\userEvent;

// use App\Mail\newMail;

// class newListener
// {
//     /**
//      * Create the event listener.
//      *
//      * @return void
//      */
//     public function __construct()
//     {
//         //
//     }

//     /**
//      * Handle the event.
//      *
//      * @param  userEvent  $event
//      * @return void
//      */
//     public function handle(UserCreated $event)
//     {
//         Mail::to($event->user->email)->send(new newMail($event->user));
//     //     echo $event->email;
//      }
// }
