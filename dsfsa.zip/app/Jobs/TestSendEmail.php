<?php

// namespace App\Jobs;

// use App\Mail\newMail;

// class TestSendEmail extends Job
// {
//     /**
//      * Create a new job instance.
//      *
//      * @return void
//      */
//     public function __construct()
//     {
//         //
//     }

//     /**
//      * Execute the job.
//      *
//      * @return void
//      */
//     public function handle()
//     {
//         $email = new newMail();
//         Mail::to('mahajanjyoti2810@gmail.com')->send($email);
//     }
// }
