<?php
// namespace App\Http\Controllers\Admin;
// use App\Http\Controllers\Controller;
// use Illuminate\Http\Request;

// class TestAdminController extends Controller{
//     public function index(Request $request,$id){
//         $name=route('testAdmin');//Test Admin Controller Activated- GET 45 http://localhost:8000/test/{id}/details
//         return"Test Admin Controller Activated- {$request ->method()} {$id} {$name}"; 
        //Test Admin Controller Activated- 45
  //  }
//}
