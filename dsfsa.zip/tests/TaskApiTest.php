 <?php


// use Tests\TestCase;
// use Laravel\Lumen\Testing\DatabaseMigrations;
// use Laravel\Lumen\Testing\DatabaseTransactions;
// use Illuminate\Foundation\Testing\RefreshDatabase;

// class TaskApiTest extends TestCase
// {
//     /**
//      * A basic test example.
//      *
//      * @return void
//      */
//     public function test_can_create_task()
//     {   $formData=[
//         'title'=>'task1',
//         'price'=>'300',
//         'description'=>'first task'
//     ];
   

//         $this->json('POST',route('tasks.store'),$formData)
//               ->assertStatus(201)
//               ;
//     }
// }
